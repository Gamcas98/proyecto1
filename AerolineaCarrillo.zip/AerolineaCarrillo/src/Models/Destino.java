/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author Gamcas
 */
public class Destino {
    
    private String nombreDestino;
    private double cuota;

    public String getNombreDestino() {
        return nombreDestino;
    }

    public double getCuota() {
        return cuota;
    }

    public void setNombreDestino(String nombreDestino) {
        this.nombreDestino = nombreDestino;
    }

    public void setCuota(double cuota) {
        this.cuota = cuota;
    }
    
   
}
