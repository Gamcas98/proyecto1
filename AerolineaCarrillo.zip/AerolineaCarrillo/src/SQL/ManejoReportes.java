/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQL;

import java.awt.Color;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;

/**
 *
 * @author Gamcas
 */
public class ManejoReportes {

    public static void mostrarPaquetesReporte(JTable tabla, String estado) {

        DefaultTaBleModel modelo = new DefaultTaBleModel();
        tabla.setModel(modelo);
        tabla.setSelectionBackground(Color.GRAY);
        tabla.setRowHeight(40);
        tabla.getTableHeader().setReorderingAllowed(false);

        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT Destino,Nombre FROM RUTA WHERE Estado=?";
        try {
            ps = Conexion.getConection().prepareStatement(query);
            ps.setString(1, estado);
            rs = ps.executeQuery();
            modelo.addColumn("Destino");
            modelo.addColumn("Ruta");
            modelo.addColumn("Paquetes en Ruta");
            modelo.addColumn("Paquetes fuera de Ruta");

            while (rs.next()) {
                String[] filas = new String[4];

                filas[0] = rs.getString(1);
                filas[1] = rs.getString(2);
                filas[2] = String.valueOf(ObtenerDatos.obtenerPaquetesEnRuta(filas[1]));
                filas[3] = String.valueOf(ObtenerDatos.obtenerPaquetesEntregados(filas[1]));

                modelo.addRow(filas);
            }

        } catch (SQLException | ClassNotFoundException ex) {
        }

    }

    public static void mostarGanancias(JTable tabla, String ruta) {

        DefaultTaBleModel modelo = new DefaultTaBleModel();
        tabla.setModel(modelo);
        tabla.setSelectionBackground(Color.GRAY);
        tabla.setRowHeight(40);
        tabla.getTableHeader().setReorderingAllowed(false);

//        PreparedStatement ps = null;
//        ResultSet rs = null;
        String[] filas = new String[4];

        String query = "SELECT Nombre, Destino FROM RUTA WHERE Nombre LIKE ?";
        try {
          PreparedStatement  ps = Conexion.getConection().prepareStatement(query);
          ps.setString(1, "%" + ruta + "%");
           ResultSet rs = ps.executeQuery();
            modelo.addColumn("Ruta");
            modelo.addColumn("Costos");
            modelo.addColumn("Ingresos");
            modelo.addColumn("Ganancias");

            while (rs.next()) {
                
                double costo = 0;
                double ingreso = 0;
                double ganancias = 0;

                filas[0] = rs.getString(1);

                String query2 = "SELECT id_paquete,costo, ingreso FROM PAQUETE WHERE Ruta=? AND Estado='Entregado'";
                PreparedStatement ps2 = Conexion.getConection().prepareStatement(query2);;
                ps2.setString(1, rs.getString(1));
                ResultSet rs2 = ps2.executeQuery();

                while (rs2.next()) {
                    costo = costo + rs2.getDouble(2);
                    ingreso = ingreso + rs2.getDouble(3);
                    ganancias = ingreso - costo;
                }

                filas[1] = String.valueOf(costo);
                filas[2] = String.valueOf(ingreso);
                filas[3] = String.valueOf(ganancias);

                modelo.addRow(filas);

            }

        } catch (SQLException | ClassNotFoundException ex) {
        }

    }

}
