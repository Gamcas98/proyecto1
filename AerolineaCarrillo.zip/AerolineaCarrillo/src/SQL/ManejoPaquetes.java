/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQL;

import Models.Cliente;
import Models.Paquete;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Gamcas
 */
public class ManejoPaquetes {

    //metodo para obtener la tarifa de operacion de algun punto de control en especifico
    //este metodo nos sirve para calcular el costo de cada paquete en dicho punto
    public static int obtenerTarifaPunto(String nombre, int id) {

        try {
            PreparedStatement ps = null;
            ResultSet rs = null;

            String query = "SELECT tarifa_operacion FROM punto_de_control WHERE Ruta=? AND id_punto_control=?";

            ps = Conexion.getConection().prepareStatement(query);
            ps.setString(1, nombre);
            ps.setInt(2, id);
            rs = ps.executeQuery();
//si rs nos trae datos
            if (rs.next()) {
                int numero = rs.getInt(1);//varibale para almacenar el dato que nos trae rs
                return numero;//y retornamos el valor para manejarlo afuera
            }

            return 0;
        } catch (SQLException | ClassNotFoundException ex) {
            return 0;
        }

    }

//metodo que nos devuelve el paquete que esta a la cabeza de la cola en cuaquier punto de control
    public static int obtenerPrimerPaquete(String ruta, int id) {

        try {
            PreparedStatement ps = null;
            ResultSet rs = null;

            String query = "SELECT id_paquete FROM PAQUETE WHERE Ruta=? AND punto_control=? AND Estado='Ruta' ORDER BY fecha_ingreso ASC LIMIT 1";

            ps = Conexion.getConection().prepareStatement(query);
            ps.setString(1, ruta);
            ps.setInt(2, id);
            rs = ps.executeQuery();
//si rs nos trae datos
            if (rs.next()) {
                int numero = rs.getInt(1);//varibale para almacenar el dato que nos trae rs
                return numero;//y retornamos el valor para manejarlo afuera
            }

            return 0;
        } catch (SQLException | ClassNotFoundException ex) {
            return 0;
        }

    }

//metodo para mover un paquete de un punto de control a otro o a su destino
    public static boolean moverPaquete(Object punto, int destino, int horas, double costo, String estado) {

        PreparedStatement ps = null;

        String query = "UPDATE PAQUETE SET punto_control=?,horas_en_ruta=?,costo=?,Estado=? WHERE id_paquete=?";

        try {
            ps = Conexion.getConection().prepareStatement(query);
            ps.setObject(1, punto);
            ps.setInt(2, horas);
            ps.setDouble(3, costo);
            ps.setString(4, estado);
            ps.setInt(5, destino);
            ps.execute();
            return true;
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
            return false;
        }

    }

    //metodo para mover los paquetes de bodega hacia los puntos de control que se vayan vaciando
    public static boolean moverPaqueteBodega(Object punto, String ruta, int id) {

        PreparedStatement ps = null;

        String query = "UPDATE PAQUETE SET punto_control=?,ruta=?,Estado=? WHERE id_paquete=?";

        try {
            ps = Conexion.getConection().prepareStatement(query);
            ps.setObject(1, punto);
            ps.setString(2, ruta);
            ps.setString(3, "Ruta");
            ps.setInt(4, id);

            ps.execute();
            return true;
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
            return false;
        }

    }

    //metodo que nos devuelve la cantidad de puntos de control que una ruta posee
    public static int obtenerPuntosrRuta(String nombre) {

        try {
            PreparedStatement ps = null;
            ResultSet rs = null;

            String query = "SELECT COUNT(id_punto_control) FROM punto_de_control WHERE Ruta=?";

            ps = Conexion.getConection().prepareStatement(query);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
//si rs nos trae datos
            if (rs.next()) {
                int numero = rs.getInt(1);//varibale para almacenar el dato que nos trae rs
                return numero;//y retornamos el valor para manejarlo afuera
            }

            return 0;
        } catch (SQLException | ClassNotFoundException ex) {
            return 0;
        }

    }

//metodo para obtener las horas que lleva el paquete en ruta
    public static int obtenerHoras(int paquete) {

        try {
            PreparedStatement ps = null;
            ResultSet rs = null;
            String query = "SELECT horas_en_ruta FROM PAQUETE WHERE id_paquete=?";

            ps = Conexion.getConection().prepareStatement(query);
            ps.setInt(1, paquete);
            rs = ps.executeQuery();
//si rs nos trae datos
            if (rs.next()) {
                int numero = rs.getInt(1);//varibale para almacenar el dato que nos trae rs
                return numero;//y retornamos el valor para manejarlo afuera
            }

            return 0;
        } catch (SQLException | ClassNotFoundException ex) {
            return 0;
        }

    }

    //metodo que nos devuelve el costo de cada paquete en los puntos de control
    //nos sirve para calcular el costo de operacion total
    public static int obtenerCosto(int paquete) {

        try {
            PreparedStatement ps = null;
            ResultSet rs = null;
//consulta para ver el ultimo caso que se ingreso
            String query = "SELECT costo FROM PAQUETE WHERE id_paquete=?";

            ps = Conexion.getConection().prepareStatement(query);
            ps.setInt(1, paquete);
            rs = ps.executeQuery();
//si rs nos trae datos
            if (rs.next()) {
                int numero = rs.getInt(1);//varibale para almacenar el dato que nos trae rs
                return numero;//y retornamos el valor para manejarlo afuera
            }

            return 0;
        } catch (SQLException | ClassNotFoundException ex) {
            return 0;
        }

    }

    //metodo que nos devuelve el primer paquete que esta esperando en la cola de bodega 
    public static Paquete recuperarPaquete() {
        Paquete paquete = new Paquete();

        try {
            PreparedStatement ps = null;
            ResultSet rs = null;

            String query = "SELECT Destino,id_paquete,costo FROM PAQUETE WHERE tarifa_prioridad=0 AND Estado='Bodega' ";

            ps = Conexion.getConection().prepareStatement(query);
            rs = ps.executeQuery();
//si rs nos trae datos
            if (rs.next()) {
                paquete.setDestino(rs.getString(1));
                paquete.setId(rs.getInt(2));
                paquete.setCosto(rs.getDouble(3));
                return paquete;
            }

            return null;
        } catch (SQLException | ClassNotFoundException ex) {
            return null;
        }
    }

    //metodo que nos devuelve el primer paquete priorizado que esta en la cola de bodega
    //este paquete tiene priordad sobre los paquetes sin prioridad que se recuperan en el metodo de arriba
    public static Paquete recuperarPaquetePriorizado() {
        Paquete paquete = new Paquete();

        try {
            PreparedStatement ps = null;
            ResultSet rs = null;
//consulta para ver el ultimo caso que se ingreso
            String query = "SELECT Destino,id_paquete,costo FROM PAQUETE WHERE tarifa_prioridad>0 AND Estado='Bodega' ";

            ps = Conexion.getConection().prepareStatement(query);
            rs = ps.executeQuery();
//si rs nos trae datos
            if (rs.next()) {
                paquete.setDestino(rs.getString(1));
                paquete.setId(rs.getInt(2));
                paquete.setCosto(rs.getDouble(3));
                return paquete;
            }

            return null;
        } catch (SQLException | ClassNotFoundException ex) {
            return null;
        }
    }

}
