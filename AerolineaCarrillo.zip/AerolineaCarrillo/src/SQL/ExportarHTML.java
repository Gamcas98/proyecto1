/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQL;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Gamcas
 */
public class ExportarHTML {

    public static void rutasToHtml(String estado) {

        File file = new File("Rutas" + estado + ".html");

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException ex) {
            }
        }
        try {
            PrintWriter pw = new PrintWriter(file, "utf-8");
            pw.println("<html>");
            pw.println("<head><title>" + "REPORTE DE RUTAS" + "</title></head>");
            pw.println("<body>");
            pw.printf("<h1>" + "RUTAS" + " </h1>");
            pw.println("<table>     ");
            pw.printf("<tr>");
            pw.printf("<td><strong>" + "Destino" + "  </strong></td>");
            pw.printf("<td><strong>" + "Ruta" + "  </strong></td>");
            pw.printf("<td><strong>" + "Paquetes en Ruta" + "  </strong></td>");
            pw.printf("<td><strong>" + "Paquetes fuera de Ruta" + "  </strong></td>");
            pw.printf("</tr>");

            PreparedStatement ps = null;
            ResultSet rs = null;

            String query = "SELECT Destino,Nombre FROM RUTA WHERE Estado=?";

            try {
                ps = Conexion.getConection().prepareStatement(query);
                ps.setString(1, estado);
                rs = ps.executeQuery();

                while (rs.next()) {
                    pw.printf("<tr>");
                    pw.printf("<td>" + rs.getString(1) + "   </td>");
                    pw.printf("<td>" + rs.getString(2) + "   </td>");
                    pw.printf("<td>" + String.valueOf(ObtenerDatos.obtenerPaquetesEnRuta(rs.getString(2))) + "   </td>");
                    pw.printf("<td>" + String.valueOf(ObtenerDatos.obtenerPaquetesEnRuta(rs.getString(2))) + "   </td>");
                    pw.printf("</tr>");
                }

            } catch (SQLException | ClassNotFoundException ex) {

            }
            pw.printf("</table>");
            pw.printf("</body>");
            pw.printf("</html>");
            pw.close();
        } catch (IOException ex) {
        }
    }

    public static void GananciasToHtml(String ruta) {

        File file = new File("Ganancias" + ruta + ".html");

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException ex) {
            }
        }
        try {
            PrintWriter pw = new PrintWriter(file, "utf-8");
            pw.println("<html>");
            pw.println("<head><title>" + "REPORTE DE Ganancias" + "</title></head>");
            pw.println("<body>");
            pw.printf("<h1>" + "Ganancias" + " </h1>");
            pw.println("<table>     ");
            pw.printf("<tr>");
            pw.printf("<td><strong>" + "Ruta" + "  </strong></td>");
            pw.printf("<td><strong>" + "Costos" + "  </strong></td>");
            pw.printf("<td><strong>" + "Ingresos" + "  </strong></td>");
            pw.printf("<td><strong>" + "Ganancias" + "  </strong></td>");
            pw.printf("</tr>");

            String query = "SELECT Nombre, Destino FROM RUTA WHERE Nombre LIKE ?";
            try {
                PreparedStatement ps = Conexion.getConection().prepareStatement(query);
                ps.setString(1, "%" + ruta + "%");

                ResultSet rs = ps.executeQuery();

                while (rs.next()) {

                    double costo = 0;
                    double ingreso = 0;
                    double ganancias = 0;

                    String query2 = "SELECT id_paquete,costo, ingreso FROM PAQUETE WHERE Ruta=? AND Estado='Entregado'";
                    PreparedStatement ps2 = Conexion.getConection().prepareStatement(query2);;
                    ps2.setString(1, rs.getString(1));
                    ResultSet rs2 = ps2.executeQuery();
                    pw.printf("<tr>");
                    pw.printf("<td>" + rs.getString(1) + "   </td>");
                    while (rs2.next()) {
                        costo = costo + rs2.getDouble(2);
                        ingreso = ingreso + rs2.getDouble(3);
                        ganancias = ingreso - costo;

                    }
                    pw.printf("<td>" + String.valueOf(costo) + "   </td>");
                    pw.printf("<td>" + String.valueOf(ingreso) + "   </td>");
                    pw.printf("<td>" + String.valueOf(ganancias) + "   </td>");
                    pw.printf("</tr>");
                }

            } catch (SQLException | ClassNotFoundException ex) {

            }
            pw.printf("</table>");
            pw.printf("</body>");
            pw.printf("</html>");
            pw.close();
        } catch (IOException ex) {
        }
    }
}
