CREATE DATABASE  IF NOT EXISTS `control_paquetes` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `control_paquetes`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: control_paquetes
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `punto_de_control`
--

DROP TABLE IF EXISTS `punto_de_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `punto_de_control` (
  `id_punto_control` int(11) NOT NULL,
  `tarifa_operacion` double NOT NULL,
  `cantidad_paquetes` int(11) NOT NULL,
  `Usuario` varchar(30) NOT NULL,
  `Ruta` varchar(30) NOT NULL,
  `Estado` varchar(10) NOT NULL,
  `Cola` int(11) NOT NULL,
  PRIMARY KEY (`id_punto_control`,`Ruta`),
  KEY `FK_RUTA_IN_PUNTO_DE_CONTROL` (`Ruta`),
  KEY `FK_USUARIO_IN_PUNTO_CONTROL` (`Usuario`),
  CONSTRAINT `FK_RUTA_IN_PUNTO_DE_CONTROL` FOREIGN KEY (`Ruta`) REFERENCES `ruta` (`Nombre`),
  CONSTRAINT `FK_USUARIO_IN_PUNTO_CONTROL` FOREIGN KEY (`Usuario`) REFERENCES `usuario` (`Usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `punto_de_control`
--

LOCK TABLES `punto_de_control` WRITE;
/*!40000 ALTER TABLE `punto_de_control` DISABLE KEYS */;
INSERT INTO `punto_de_control` VALUES (1,25,5,'Anton','Nacional','ACTIVO',3),(1,25,5,'Anton','Nacional 2','ACTIVO',0),(1,25,6,'Escobar','Nueva','ACTIVO',4),(1,25,5,'Anton','Tierra Fria','ACTIVO',2),(1,35,5,'Valiente','Vieja','ACTIVO',0),(2,30,7,'Escobar','Nacional','ACTIVO',0),(2,30,6,'Anton','Nacional 2','ACTIVO',0),(2,30,6,'Anton','Nueva','ACTIVO',0),(2,20,4,'Escobar','Tierra Fria','ACTIVO',0),(2,25,6,'Valiente','Vieja','ACTIVO',0),(3,20,4,'Valiente','Nacional','ACTIVO',0),(3,25,4,'Escobar','Nacional 2','ACTIVO',0),(3,35,7,'Valiente','Nueva','ACTIVO',0),(3,15,3,'Valiente','Tierra Fria','ACTIVO',0),(3,20,6,'Anton','Vieja','ACTIVO',0),(4,35,3,'Anton','Nacional','ACTIVO',0),(4,35,6,'Escobar','Nacional 2','ACTIVO',0),(4,30,6,'Valiente','Nueva','ACTIVO',0),(4,25,5,'Escobar','Tierra Fria','ACTIVO',0),(4,25,6,'Anton','Vieja','ACTIVO',0);
/*!40000 ALTER TABLE `punto_de_control` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-26 13:58:30
