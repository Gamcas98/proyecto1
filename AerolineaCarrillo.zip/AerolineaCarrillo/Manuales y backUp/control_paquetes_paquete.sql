CREATE DATABASE  IF NOT EXISTS `control_paquetes` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `control_paquetes`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: control_paquetes
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `paquete`
--

DROP TABLE IF EXISTS `paquete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paquete` (
  `id_paquete` int(11) NOT NULL AUTO_INCREMENT,
  `nit_cliente` int(11) NOT NULL,
  `horas_en_ruta` int(11) DEFAULT NULL,
  `Estado` varchar(25) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `fecha_recepcion` date DEFAULT NULL,
  `tarifa_Prioridad` double NOT NULL,
  `tarifa_libra` double NOT NULL,
  `tarifa_destino` double NOT NULL,
  `Peso` int(11) NOT NULL,
  `Ruta` varchar(30) DEFAULT NULL,
  `Punto_control` int(11) DEFAULT NULL,
  `Destino` varchar(30) DEFAULT NULL,
  `Costo` int(11) DEFAULT NULL,
  `Ingreso` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_paquete`),
  KEY `FK_RUTA_IN_PAQUETE` (`Ruta`),
  KEY `FK_DESTINO_IN_PAQUETE` (`Destino`),
  KEY `FK_PUNTO_DE_CONTROL_IN_PAQUETE` (`Punto_control`),
  CONSTRAINT `FK_DESTINO_IN_PAQUETE` FOREIGN KEY (`Destino`) REFERENCES `destino` (`nombre_destino`),
  CONSTRAINT `FK_PUNTO_DE_CONTROL_IN_PAQUETE` FOREIGN KEY (`Punto_control`) REFERENCES `punto_de_control` (`id_punto_control`),
  CONSTRAINT `FK_RUTA_IN_PAQUETE` FOREIGN KEY (`Ruta`) REFERENCES `ruta` (`Nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paquete`
--

LOCK TABLES `paquete` WRITE;
/*!40000 ALTER TABLE `paquete` DISABLE KEYS */;
INSERT INTO `paquete` VALUES (1,1762653,6,'Entregado','2019-08-26','2019-08-28',0,30,200,4,'Nacional',NULL,'Guatemala',155,320),(2,1762653,8,'Entregado','2019-08-26','2019-08-31',0,30,150,6,'Tierra Fria',NULL,'San Marcos',170,330),(3,1762653,8,'Entregado','2019-08-26','2019-09-02',0,30,250,4,'Nueva',NULL,'Huehuetenango',235,370),(4,1762653,8,'Entregado','2019-08-26','2019-08-30',0,30,250,3,'Nueva',NULL,'Huehuetenango',235,340),(5,1762653,5,'Entregado','2019-08-26','2019-08-29',0,30,250,7,'Nueva',NULL,'Huehuetenango',150,460),(6,1765620,7,'Entregado','2019-08-26','2019-08-28',75,30,200,6,'Nacional',NULL,'Guatemala',215,455),(7,1765620,6,'Entregado','2019-08-26','2019-08-31',0,30,200,4,'Nacional',NULL,'Guatemala',150,320),(8,1765620,7,'Entregado','2019-08-26','2019-08-30',75,30,200,5,'Nacional',NULL,'Guatemala',195,425),(9,1765621,6,'Entregado','2019-08-26','2019-08-30',75,30,250,4,'Nueva',NULL,'Huehuetenango',175,445),(10,1765621,4,'Entregado','2019-08-26','2019-08-30',0,30,250,5,'Nueva',NULL,'Huehuetenango',120,400),(11,1765621,5,'Entregado','2019-08-26','2019-08-30',0,30,250,3,'Nueva',NULL,'Huehuetenango',145,340),(12,1785963,6,'Entregado','2019-08-26','2019-08-26',75,30,150,6,'Tierra Fria',NULL,'San Marcos',125,405),(13,1785963,6,'Entregado','2019-08-26','2019-08-26',0,30,150,5,'Tierra Fria',NULL,'San Marcos',135,300),(14,1785963,6,'Entregado','2019-08-26','2019-08-26',0,30,150,6,'Tierra Fria',NULL,'San Marcos',130,330),(15,1765620,0,'Ruta','2019-08-26',NULL,0,30,200,4,'Nacional',1,'Guatemala',0,320),(16,1765620,0,'Ruta','2019-08-26',NULL,0,30,250,4,'Nueva',1,'Huehuetenango',0,370),(17,1765620,0,'Ruta','2019-08-26',NULL,0,30,150,4,'Tierra Fria',1,'San Marcos',0,270),(18,1765621,0,'Ruta','2019-08-26',NULL,75,30,250,6,'Nueva',1,'Huehuetenango',0,505),(19,1765621,0,'Ruta','2019-08-26',NULL,0,30,200,5,'Nacional',1,'Guatemala',0,350),(20,1765621,0,'Ruta','2019-08-26',NULL,0,30,200,5,'Nacional',1,'Guatemala',0,350),(21,1762653,0,'Ruta','2019-08-26',NULL,0,30,150,5,'Tierra Fria',1,'San Marcos',0,300),(22,1762653,0,'Ruta','2019-08-26',NULL,0,30,250,5,'Nueva',1,'Huehuetenango',0,400),(23,1762653,0,'Ruta','2019-08-26',NULL,0,30,250,4,'Nueva',1,'Huehuetenango',0,370);
/*!40000 ALTER TABLE `paquete` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-26 13:58:31
